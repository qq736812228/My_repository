import request from './request'

export interface LoginPayload {
  username: string
  password: string
}

export const login = (data: LoginPayload) => request.post('/api/auth/login', data)
export const dashboardOverview = () => request.get('/api/admin/dashboard/overview')

export const crud = {
  list: (endpoint: string) => request.get(`/api/admin/${endpoint}`),
  detail: (endpoint: string, id: number) => request.get(`/api/admin/${endpoint}/${id}`),
  create: (endpoint: string, data: Record<string, unknown>) => request.post(`/api/admin/${endpoint}`, data),
  update: (endpoint: string, id: number, data: Record<string, unknown>) => request.put(`/api/admin/${endpoint}/${id}`, data),
  remove: (endpoint: string, id: number) => request.delete(`/api/admin/${endpoint}/${id}`)
}
