INSERT INTO mall_product_category(category_code, category_name, parent_code, description, sort_order) VALUES
('A','菌检服务',NULL,'16S、宏基因组、专项微生态检测',1),
('B','益生菌/菌株制品',NULL,'单菌株、多菌株复配与明确菌株产品',2),
('C','益生元/膳食纤维',NULL,'菊粉、低聚果糖、抗性糊精等',3),
('D','后生元/灭活菌/发酵代谢物',NULL,'灭活菌、菌体成分、发酵代谢物',4),
('E','发酵食品',NULL,'酸奶、奶酪、纳豆、腐乳、泡菜等',5),
('F','营养支持类产品',NULL,'蛋白、维生素矿物质、植物营养素等',6),
('G','康养服务/解读服务',NULL,'报告解读、营养师服务、家庭微生态管理',7),
('H','设备与记录工具',NULL,'体脂秤、睡眠、穿戴、记录工具',8),
('Z','空位以待',NULL,'需求已被看见，产品仍待验证',99)
ON CONFLICT(category_code) DO NOTHING;

INSERT INTO mall_claim_risk_rule(keyword, risk_type, risk_level) VALUES
('根治','DISEASE_TREATMENT','HIGH'),
('治愈','DISEASE_TREATMENT','HIGH'),
('替代药物','MEDICAL_REPLACEMENT','HIGH'),
('保证有效','ABSOLUTE_CLAIM','HIGH'),
('治疗','DISEASE_TREATMENT','HIGH'),
('降血糖','DISEASE_CLAIM','MEDIUM'),
('降血脂','DISEASE_CLAIM','MEDIUM'),
('抗癌','DISEASE_TREATMENT','HIGH'),
('包好','ABSOLUTE_CLAIM','HIGH')
ON CONFLICT DO NOTHING;

INSERT INTO mall_empty_slot(slot_code, slot_name, slot_type, category_code, demand_tag, reason, display_text, conversion_condition) VALUES
('Z1-BIFIDO-EVIDENCE','双歧杆菌方向空位','STRAIN_EVIDENCE','B','BIFIDOBACTERIUM','用户需求存在，但当前缺少菌株编号、批次检测、长期反馈均完整的可信产品','空位以待：需求已被看见，产品仍待验证。','明确菌株编号、提供批次检测、通过宣传合规审核、进入用户反馈闭环'),
('Z3-PROBIOTIC-LOW-EVIDENCE','证据不足益生菌空位','INSUFFICIENT_EVIDENCE','B','PROBIOTIC_GENERAL','市场存在相关产品，但公开信息不足以支持正式推荐','平台不会为了填满货架而降低标准。','企业认领并补充菌株、活菌数、到期活菌数和检测资料'),
('Z5-MEDICAL-BOUNDARY','医疗边界空位','COMPLIANCE_BOUNDARY','B','MEDICAL_BOUNDARY','涉及疾病/医疗边界，平台暂不设置商品化推荐','该方向涉及专业健康边界，仅保留记录、研究和专业咨询入口。','完成法务与医学合规审查')
ON CONFLICT(slot_code) DO NOTHING;

INSERT INTO mall_product(product_code, product_name, brand_name, category_code, product_type, status, source_type, specification, claim_summary, info_integrity_score, total_score, obai_level)
VALUES
('PUB-0001','公开收录示例：复合益生菌产品','示例品牌','B','PROBIOTIC','PUBLIC_COLLECTED','PUBLIC','2g x 30条','标称复合益生菌，公开信息待补',35,35,'D')
ON CONFLICT(product_code) DO NOTHING;
