CREATE TABLE IF NOT EXISTS mall_product_category (
    id BIGSERIAL PRIMARY KEY,
    category_code VARCHAR(32) UNIQUE NOT NULL,
    category_name VARCHAR(128) NOT NULL,
    parent_code VARCHAR(32),
    description TEXT,
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS mall_product (
    id BIGSERIAL PRIMARY KEY,
    product_code VARCHAR(64) UNIQUE NOT NULL,
    product_name VARCHAR(255) NOT NULL,
    brand_name VARCHAR(128),
    manufacturer_name VARCHAR(255),
    entrust_company_name VARCHAR(255),
    category_code VARCHAR(32) NOT NULL,
    product_type VARCHAR(32) NOT NULL,
    status VARCHAR(32) NOT NULL DEFAULT 'PUBLIC_COLLECTED',
    source_type VARCHAR(32) NOT NULL DEFAULT 'PUBLIC',
    public_source_url TEXT,
    specification VARCHAR(255),
    storage_condition TEXT,
    suitable_population TEXT,
    unsuitable_population TEXT,
    claim_summary TEXT,
    info_integrity_score NUMERIC(5,2) DEFAULT 0,
    evidence_score NUMERIC(5,2) DEFAULT 0,
    risk_score NUMERIC(5,2) DEFAULT 0,
    total_score NUMERIC(5,2) DEFAULT 0,
    obai_level VARCHAR(16) DEFAULT 'D',
    is_recommendable BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_mall_product_category ON mall_product(category_code);
CREATE INDEX IF NOT EXISTS idx_mall_product_status ON mall_product(status);

CREATE TABLE IF NOT EXISTS mall_strain (
    id BIGSERIAL PRIMARY KEY,
    strain_code VARCHAR(128) UNIQUE NOT NULL,
    species_name VARCHAR(255) NOT NULL,
    genus_name VARCHAR(255),
    strain_no VARCHAR(128),
    source_description TEXT,
    owner_company VARCHAR(255),
    authorization_status VARCHAR(32),
    food_use_scope VARCHAR(255),
    infant_allowed BOOLEAN DEFAULT FALSE,
    has_human_evidence BOOLEAN DEFAULT FALSE,
    has_industrial_capacity BOOLEAN DEFAULT FALSE,
    has_batch_test BOOLEAN DEFAULT FALSE,
    evidence_level VARCHAR(16) DEFAULT 'C',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_mall_strain_species ON mall_strain(species_name);

CREATE TABLE IF NOT EXISTS mall_product_strain (
    id BIGSERIAL PRIMARY KEY,
    product_id BIGINT NOT NULL REFERENCES mall_product(id) ON DELETE CASCADE,
    strain_id BIGINT REFERENCES mall_strain(id),
    declared_species VARCHAR(255),
    declared_strain_no VARCHAR(128),
    declared_cfu VARCHAR(128),
    cfu_at_production VARCHAR(128),
    cfu_at_expiry VARCHAR(128),
    is_declared_clear BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS mall_enterprise_claim (
    id BIGSERIAL PRIMARY KEY,
    product_id BIGINT NOT NULL REFERENCES mall_product(id) ON DELETE CASCADE,
    enterprise_name VARCHAR(255) NOT NULL,
    unified_social_credit_code VARCHAR(64),
    contact_name VARCHAR(64),
    contact_phone VARCHAR(64),
    claim_reason TEXT,
    status VARCHAR(32) DEFAULT 'PENDING',
    audit_comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS mall_evidence_file (
    id BIGSERIAL PRIMARY KEY,
    product_id BIGINT REFERENCES mall_product(id) ON DELETE CASCADE,
    strain_id BIGINT REFERENCES mall_strain(id),
    batch_id BIGINT,
    evidence_type VARCHAR(64) NOT NULL,
    file_name VARCHAR(255),
    file_url TEXT,
    issuer VARCHAR(255),
    issue_date DATE,
    expire_date DATE,
    audit_status VARCHAR(32) DEFAULT 'PENDING',
    audit_comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS mall_batch_record (
    id BIGSERIAL PRIMARY KEY,
    product_id BIGINT NOT NULL REFERENCES mall_product(id) ON DELETE CASCADE,
    batch_no VARCHAR(128) NOT NULL,
    production_date DATE,
    expire_date DATE,
    cfu_test_result VARCHAR(255),
    test_institution VARCHAR(255),
    sample_retention BOOLEAN DEFAULT FALSE,
    storage_condition TEXT,
    audit_status VARCHAR(32) DEFAULT 'PENDING',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS mall_price_snapshot (
    id BIGSERIAL PRIMARY KEY,
    product_id BIGINT NOT NULL REFERENCES mall_product(id) ON DELETE CASCADE,
    platform_name VARCHAR(128) NOT NULL,
    shop_name VARCHAR(255),
    price NUMERIC(12,2),
    unit_price NUMERIC(12,4),
    specification VARCHAR(255),
    sales_count INTEGER,
    commission_rate NUMERIC(6,2),
    source_url TEXT,
    captured_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS mall_claim_risk_rule (
    id BIGSERIAL PRIMARY KEY,
    keyword VARCHAR(128) NOT NULL,
    risk_type VARCHAR(64) NOT NULL,
    risk_level VARCHAR(16) NOT NULL,
    enabled BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS mall_claim_risk (
    id BIGSERIAL PRIMARY KEY,
    product_id BIGINT NOT NULL REFERENCES mall_product(id) ON DELETE CASCADE,
    claim_text TEXT NOT NULL,
    risk_type VARCHAR(64),
    risk_level VARCHAR(16),
    matched_keywords TEXT,
    review_status VARCHAR(32) DEFAULT 'AUTO_DETECTED',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS mall_product_feedback (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL,
    product_id BIGINT NOT NULL REFERENCES mall_product(id) ON DELETE CASCADE,
    use_start_date DATE,
    use_end_date DATE,
    dose_description VARCHAR(255),
    stool_change_score INTEGER,
    sleep_change_score INTEGER,
    energy_change_score INTEGER,
    digestion_change_score INTEGER,
    adverse_feedback TEXT,
    overall_feedback TEXT,
    retest_id BIGINT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS mall_empty_slot (
    id BIGSERIAL PRIMARY KEY,
    slot_code VARCHAR(64) UNIQUE NOT NULL,
    slot_name VARCHAR(255) NOT NULL,
    slot_type VARCHAR(32) NOT NULL,
    category_code VARCHAR(32),
    demand_tag VARCHAR(128),
    reason TEXT NOT NULL,
    display_text TEXT,
    status VARCHAR(32) DEFAULT 'WAITING',
    conversion_condition TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS mall_slot_candidate_product (
    id BIGSERIAL PRIMARY KEY,
    slot_id BIGINT NOT NULL REFERENCES mall_empty_slot(id) ON DELETE CASCADE,
    product_id BIGINT NOT NULL REFERENCES mall_product(id) ON DELETE CASCADE,
    reason TEXT,
    status VARCHAR(32) DEFAULT 'CANDIDATE',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS mall_product_score (
    id BIGSERIAL PRIMARY KEY,
    product_id BIGINT NOT NULL REFERENCES mall_product(id) ON DELETE CASCADE,
    info_score NUMERIC(5,2) DEFAULT 0,
    strain_score NUMERIC(5,2) DEFAULT 0,
    batch_score NUMERIC(5,2) DEFAULT 0,
    claim_score NUMERIC(5,2) DEFAULT 0,
    price_score NUMERIC(5,2) DEFAULT 0,
    feedback_score NUMERIC(5,2) DEFAULT 0,
    total_score NUMERIC(5,2) DEFAULT 0,
    obai_level VARCHAR(16),
    calculated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS operation_log (
    id BIGSERIAL PRIMARY KEY,
    operator_id BIGINT,
    operator_name VARCHAR(128),
    module_name VARCHAR(128),
    action_name VARCHAR(128),
    target_type VARCHAR(128),
    target_id BIGINT,
    before_data JSONB,
    after_data JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
