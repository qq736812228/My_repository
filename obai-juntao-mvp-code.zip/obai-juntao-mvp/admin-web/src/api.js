import axios from 'axios'
export const http = axios.create({ baseURL: 'http://localhost:8080' })
export async function listProducts(){ return (await http.get('/api/mall/products')).data.data }
export async function createProduct(data){ return (await http.post('/api/admin/mall/products', data)).data.data }
export async function recalcProduct(id){ return (await http.post(`/api/admin/mall/products/${id}/recalculate-score`)).data.data }
export async function listSlots(){ return (await http.get('/api/mall/empty-slots')).data.data }
export async function createSlot(data){ return (await http.post('/api/admin/mall/empty-slots', data)).data.data }
export async function listClaims(){ return (await http.get('/api/admin/mall/claim/applications')).data.data }
