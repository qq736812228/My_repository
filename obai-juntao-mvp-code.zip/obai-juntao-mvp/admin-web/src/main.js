import { createApp } from 'vue'
import { createPinia } from 'pinia'
import { createRouter, createWebHashHistory } from 'vue-router'
import App from './App.vue'
import ProductList from './pages/ProductList.vue'
import ProductCreate from './pages/ProductCreate.vue'
import EmptySlotList from './pages/EmptySlotList.vue'
import ClaimList from './pages/ClaimList.vue'
import './styles.css'

const routes = [
  { path: '/', redirect: '/products' },
  { path: '/products', component: ProductList },
  { path: '/products/create', component: ProductCreate },
  { path: '/slots', component: EmptySlotList },
  { path: '/claims', component: ClaimList }
]
const router = createRouter({ history: createWebHashHistory(), routes })
createApp(App).use(createPinia()).use(router).mount('#app')
