<template>
  <div class="layout">
    <aside>
      <h2>OBAI 菌淘</h2>
      <router-link to="/products">商品证据库</router-link>
      <router-link to="/products/create">公开收录</router-link>
      <router-link to="/slots">空位以待</router-link>
      <router-link to="/claims">企业认领</router-link>
    </aside>
    <main><router-view /></main>
  </div>
</template>
