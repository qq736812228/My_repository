<template>
  <div>
    <h1>公开收录商品</h1>
    <div class="card">
      <div class="grid">
        <label>商品名<input v-model="form.productName"></label>
        <label>品牌<input v-model="form.brandName"></label>
        <label>生产方<input v-model="form.manufacturerName"></label>
        <label>委托方<input v-model="form.entrustCompanyName"></label>
        <label>分类<select v-model="form.categoryCode"><option>B</option><option>C</option><option>D</option><option>E</option><option>F</option><option>G</option><option>H</option></select></label>
        <label>产品类型<input v-model="form.productType"></label>
      </div>
      <label>规格<input v-model="form.specification"></label>
      <label>储存条件<input v-model="form.storageCondition"></label>
      <label>适用边界<textarea v-model="form.suitablePopulation"></textarea></label>
      <label>宣传摘要<textarea v-model="form.claimSummary"></textarea></label>
      <button class="btn orange" @click="submit">收录并评分</button>
    </div>
  </div>
</template>
<script setup>
import { reactive } from 'vue'
import { createProduct } from '../api'
const form = reactive({ productName:'', brandName:'', manufacturerName:'', entrustCompanyName:'', categoryCode:'B', productType:'PROBIOTIC', specification:'', storageCondition:'', suitablePopulation:'', claimSummary:'' })
async function submit(){ await createProduct(form); alert('已收录') }
</script>
