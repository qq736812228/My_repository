<template>
  <div>
    <h1>商品证据库</h1>
    <div class="card">
      <table class="table">
        <thead><tr><th>名称</th><th>分类</th><th>状态</th><th>等级</th><th>评分</th><th>推荐</th><th>操作</th></tr></thead>
        <tbody>
          <tr v-for="p in products" :key="p.id">
            <td>{{p.productName}}<br><span class="pill">{{p.brandName || '公开收录'}}</span></td>
            <td>{{p.categoryCode}}</td><td>{{p.status}}</td><td>{{p.obaiLevel}}</td><td>{{p.totalScore}}</td>
            <td>{{p.isRecommendable ? '是' : '否'}}</td>
            <td><button class="btn" @click="recalc(p.id)">重算评分</button></td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>
<script setup>
import { ref, onMounted } from 'vue'
import { listProducts, recalcProduct } from '../api'
const products = ref([])
async function load(){ products.value = await listProducts() }
async function recalc(id){ await recalcProduct(id); await load() }
onMounted(load)
</script>
