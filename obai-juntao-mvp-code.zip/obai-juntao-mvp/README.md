# OBAI 菌淘 MVP 工程

三端分离：

- `backend`：Spring Boot 3 + Java 17 + PostgreSQL + Flyway + Spring Security/JWT（MVP 简化）
- `admin-web`：Vue3 + Vite + Pinia + Vue Router + Axios
- `miniapp`：uni-app 微信小程序端
- `docs`：接口、选型规则、部署说明
- `database`：PostgreSQL 全量建表与初始化数据

## 菌淘定位

菌淘不是普通商城，而是 OBAI 面向肠道微生态管理的：

> 菌品识别、菌株匹配、价格比较、证据链归档、空位以待与长期反馈归同平台。

## MVP 核心功能

1. 商品公开收录
2. 商品分类 A-H + Z 空位以待
3. 企业认领
4. 菌株资料维护
5. 证据链上传与审核
6. 商品评分
7. 全网比价快照
8. 宣传风险识别
9. 用户使用反馈
10. 空位以待创建、展示、转正

## 快速启动

### 1. 数据库

```bash
createdb obai_juntao
psql -d obai_juntao -f database/schema.sql
psql -d obai_juntao -f database/init-data.sql
```

### 2. 后端

```bash
cd backend
./mvnw spring-boot:run
```

如本地没有 `mvnw`，可执行：

```bash
mvn spring-boot:run
```

### 3. 管理端

```bash
cd admin-web
npm install
npm run dev
```

### 4. 小程序端

使用 HBuilderX 或 `uni` CLI 导入 `miniapp` 目录运行。

## 合规边界

- 平台不输出疾病诊断、治疗建议、药品替代建议。
- 商品详情页展示的是公开信息、企业补充资料、用户反馈与平台评分，不构成医疗建议。
- 无完整证据链时，不使用“假菌”结论，只显示“公开信息不足以支持判断”。
