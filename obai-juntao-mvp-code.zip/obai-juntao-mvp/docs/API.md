# 菌淘 API 摘要

## 商品

- `GET /api/mall/products`
- `GET /api/mall/products/{id}`
- `POST /api/admin/mall/products`
- `PUT /api/admin/mall/products/{id}`
- `POST /api/admin/mall/products/{id}/status`
- `POST /api/admin/mall/products/{id}/recalculate-score`

## 菌株

- `GET /api/mall/strains`
- `POST /api/admin/mall/strains`
- `POST /api/admin/mall/products/{productId}/strains`

## 企业认领

- `POST /api/mall/claim/apply`
- `GET /api/admin/mall/claim/applications`
- `POST /api/admin/mall/claim/{id}/approve`
- `POST /api/admin/mall/claim/{id}/reject`

## 证据链

- `POST /api/admin/mall/evidence`
- `POST /api/admin/mall/evidence/{id}/audit`
- `GET /api/mall/products/{id}/public-evidence`

## 比价

- `GET /api/mall/products/{id}/price-compare`
- `POST /api/admin/mall/prices`

## 空位以待

- `GET /api/mall/empty-slots`
- `POST /api/admin/mall/empty-slots`
- `POST /api/admin/mall/empty-slots/{id}/convert`

## 反馈

- `POST /api/mall/products/{id}/feedback`
- `GET /api/mall/users/me/product-feedback`
