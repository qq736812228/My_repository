# Backend

接口文档启动后访问：

- `http://localhost:8080/swagger-ui.html`

配置在 `src/main/resources/application.yml`。
