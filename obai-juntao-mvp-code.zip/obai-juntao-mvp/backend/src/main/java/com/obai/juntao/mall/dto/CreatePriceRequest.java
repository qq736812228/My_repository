package com.obai.juntao.mall.dto;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;
public record CreatePriceRequest(
        @NotNull Long productId,
        String platformName,
        String shopName,
        BigDecimal price,
        BigDecimal unitPrice,
        String specification,
        Integer salesCount,
        BigDecimal commissionRate,
        String sourceUrl
) {}
