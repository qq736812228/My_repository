package com.obai.juntao.mall.domain;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.time.LocalDateTime;

@Getter @Setter
@Entity @Table(name = "mall_enterprise_claim")
public class MallEnterpriseClaim {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long productId;
    private String enterpriseName;
    private String unifiedSocialCreditCode;
    private String contactName;
    private String contactPhone;
    @Column(columnDefinition = "TEXT") private String claimReason;
    private String status = "PENDING";
    @Column(columnDefinition = "TEXT") private String auditComment;
    private LocalDateTime createdAt = LocalDateTime.now();
    private LocalDateTime updatedAt = LocalDateTime.now();
}
