package com.obai.juntao.mall.domain;

public enum ObaiLevel { A, B, C, D, E }
