package com.obai.juntao.mall.dto;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
public record ClaimApplyRequest(
        @NotNull Long productId,
        @NotBlank String enterpriseName,
        String unifiedSocialCreditCode,
        String contactName,
        String contactPhone,
        String claimReason
) {}
