package com.obai.juntao.mall.dto;
import java.time.LocalDate;
public record CreateFeedbackRequest(
        Long userId,
        LocalDate useStartDate,
        LocalDate useEndDate,
        String doseDescription,
        Integer stoolChangeScore,
        Integer sleepChangeScore,
        Integer energyChangeScore,
        Integer digestionChangeScore,
        String adverseFeedback,
        String overallFeedback,
        Long retestId
) {}
