package com.obai.juntao.mall.domain;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.time.LocalDateTime;

@Getter @Setter
@Entity @Table(name = "mall_strain")
public class MallStrain {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String strainCode;
    private String speciesName;
    private String genusName;
    private String strainNo;
    @Column(columnDefinition = "TEXT") private String sourceDescription;
    private String ownerCompany;
    private String authorizationStatus;
    private String foodUseScope;
    private Boolean infantAllowed = false;
    private Boolean hasHumanEvidence = false;
    private Boolean hasIndustrialCapacity = false;
    private Boolean hasBatchTest = false;
    private String evidenceLevel = "C";
    private LocalDateTime createdAt = LocalDateTime.now();
    private LocalDateTime updatedAt = LocalDateTime.now();
}
