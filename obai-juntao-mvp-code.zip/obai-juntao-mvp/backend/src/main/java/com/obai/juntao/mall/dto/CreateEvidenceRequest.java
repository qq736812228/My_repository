package com.obai.juntao.mall.dto;
import jakarta.validation.constraints.NotBlank;
public record CreateEvidenceRequest(
        Long productId,
        Long strainId,
        Long batchId,
        @NotBlank String evidenceType,
        String fileName,
        String fileUrl,
        String issuer,
        String auditComment
) {}
