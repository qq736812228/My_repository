package com.obai.juntao.mall.service;
import com.obai.juntao.mall.domain.MallEnterpriseClaim;
import com.obai.juntao.mall.dto.ClaimApplyRequest;
import com.obai.juntao.mall.repository.MallEnterpriseClaimRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
@Service @RequiredArgsConstructor
public class ClaimService {
    private final MallEnterpriseClaimRepository repository;
    public MallEnterpriseClaim apply(ClaimApplyRequest req) {
        MallEnterpriseClaim c = new MallEnterpriseClaim();
        c.setProductId(req.productId()); c.setEnterpriseName(req.enterpriseName());
        c.setUnifiedSocialCreditCode(req.unifiedSocialCreditCode()); c.setContactName(req.contactName());
        c.setContactPhone(req.contactPhone()); c.setClaimReason(req.claimReason());
        return repository.save(c);
    }
    public List<MallEnterpriseClaim> list() { return repository.findAll(); }
    public MallEnterpriseClaim audit(Long id, boolean approve, String comment) {
        MallEnterpriseClaim c = repository.findById(id).orElseThrow(() -> new IllegalArgumentException("认领申请不存在"));
        c.setStatus(approve ? "APPROVED" : "REJECTED"); c.setAuditComment(comment);
        return repository.save(c);
    }
}
