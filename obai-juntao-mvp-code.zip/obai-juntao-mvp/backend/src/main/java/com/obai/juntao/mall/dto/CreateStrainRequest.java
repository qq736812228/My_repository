package com.obai.juntao.mall.dto;
import jakarta.validation.constraints.NotBlank;
public record CreateStrainRequest(
        @NotBlank String strainCode,
        @NotBlank String speciesName,
        String genusName,
        String strainNo,
        String sourceDescription,
        String ownerCompany,
        String authorizationStatus,
        String foodUseScope,
        Boolean infantAllowed,
        Boolean hasHumanEvidence,
        Boolean hasIndustrialCapacity,
        Boolean hasBatchTest
) {}
