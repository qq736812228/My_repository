package com.obai.juntao.mall.domain;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter @Setter
@Entity @Table(name = "mall_product_feedback")
public class MallProductFeedback {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long userId;
    private Long productId;
    private LocalDate useStartDate;
    private LocalDate useEndDate;
    private String doseDescription;
    private Integer stoolChangeScore;
    private Integer sleepChangeScore;
    private Integer energyChangeScore;
    private Integer digestionChangeScore;
    @Column(columnDefinition = "TEXT") private String adverseFeedback;
    @Column(columnDefinition = "TEXT") private String overallFeedback;
    private Long retestId;
    private LocalDateTime createdAt = LocalDateTime.now();
}
