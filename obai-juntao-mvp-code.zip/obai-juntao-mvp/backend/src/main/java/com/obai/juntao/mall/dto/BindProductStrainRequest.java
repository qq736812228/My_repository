package com.obai.juntao.mall.dto;
public record BindProductStrainRequest(
        Long strainId,
        String declaredSpecies,
        String declaredStrainNo,
        String declaredCfu,
        String cfuAtProduction,
        String cfuAtExpiry,
        Boolean isDeclaredClear
) {}
