package com.obai.juntao.mall.controller;

import com.obai.juntao.common.ApiResponse;
import com.obai.juntao.mall.dto.*;
import com.obai.juntao.mall.service.*;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/mall")
public class MallPublicController {
    private final ProductService productService;
    private final StrainService strainService;
    private final EmptySlotService emptySlotService;
    private final PriceService priceService;
    private final FeedbackService feedbackService;
    private final EvidenceService evidenceService;
    private final ClaimService claimService;

    @GetMapping("/products")
    public ApiResponse<?> products() { return ApiResponse.ok(productService.list()); }

    @GetMapping("/products/{id}")
    public ApiResponse<?> product(@PathVariable Long id) { return ApiResponse.ok(productService.get(id)); }

    @GetMapping("/products/{id}/price-compare")
    public ApiResponse<?> priceCompare(@PathVariable Long id) { return ApiResponse.ok(priceService.compare(id)); }

    @GetMapping("/products/{id}/public-evidence")
    public ApiResponse<?> publicEvidence(@PathVariable Long id) { return ApiResponse.ok(evidenceService.publicEvidence(id)); }

    @PostMapping("/products/{id}/feedback")
    public ApiResponse<?> feedback(@PathVariable Long id, @RequestBody CreateFeedbackRequest req) { return ApiResponse.ok(feedbackService.create(id, req)); }

    @GetMapping("/strains")
    public ApiResponse<?> strains() { return ApiResponse.ok(strainService.list()); }

    @GetMapping("/empty-slots")
    public ApiResponse<?> slots() { return ApiResponse.ok(emptySlotService.list()); }

    @PostMapping("/claim/apply")
    public ApiResponse<?> claim(@Valid @RequestBody ClaimApplyRequest req) { return ApiResponse.ok(claimService.apply(req)); }
}
