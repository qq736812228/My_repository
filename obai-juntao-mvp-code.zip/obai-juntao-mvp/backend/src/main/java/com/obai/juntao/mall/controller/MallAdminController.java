package com.obai.juntao.mall.controller;

import com.obai.juntao.common.ApiResponse;
import com.obai.juntao.mall.domain.ProductStatus;
import com.obai.juntao.mall.dto.*;
import com.obai.juntao.mall.service.*;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/admin/mall")
public class MallAdminController {
    private final ProductService productService;
    private final StrainService strainService;
    private final EvidenceService evidenceService;
    private final PriceService priceService;
    private final EmptySlotService emptySlotService;
    private final ClaimService claimService;
    private final ProductScoreService scoreService;

    @PostMapping("/products")
    public ApiResponse<?> createProduct(@Valid @RequestBody CreateProductRequest req) { return ApiResponse.ok(productService.create(req)); }

    @PostMapping("/products/{id}/status")
    public ApiResponse<?> updateStatus(@PathVariable Long id, @Valid @RequestBody StatusUpdateRequest req) {
        return ApiResponse.ok(productService.updateStatus(id, ProductStatus.valueOf(req.status())));
    }

    @PostMapping("/products/{id}/recalculate-score")
    public ApiResponse<?> recalculate(@PathVariable Long id) { return ApiResponse.ok(scoreService.recalculate(id)); }

    @PostMapping("/strains")
    public ApiResponse<?> createStrain(@Valid @RequestBody CreateStrainRequest req) { return ApiResponse.ok(strainService.create(req)); }

    @PostMapping("/products/{productId}/strains")
    public ApiResponse<?> bindStrain(@PathVariable Long productId, @RequestBody BindProductStrainRequest req) { return ApiResponse.ok(strainService.bind(productId, req)); }

    @PostMapping("/evidence")
    public ApiResponse<?> createEvidence(@Valid @RequestBody CreateEvidenceRequest req) { return ApiResponse.ok(evidenceService.create(req)); }

    @PostMapping("/prices")
    public ApiResponse<?> createPrice(@Valid @RequestBody CreatePriceRequest req) { return ApiResponse.ok(priceService.create(req)); }

    @PostMapping("/empty-slots")
    public ApiResponse<?> createSlot(@Valid @RequestBody CreateSlotRequest req) { return ApiResponse.ok(emptySlotService.create(req)); }

    @PostMapping("/empty-slots/{id}/convert")
    public ApiResponse<?> convertSlot(@PathVariable Long id) { return ApiResponse.ok(emptySlotService.convert(id)); }

    @GetMapping("/claim/applications")
    public ApiResponse<?> claims() { return ApiResponse.ok(claimService.list()); }

    @PostMapping("/claim/{id}/approve")
    public ApiResponse<?> approve(@PathVariable Long id, @RequestParam(defaultValue = "") String comment) { return ApiResponse.ok(claimService.audit(id, true, comment)); }

    @PostMapping("/claim/{id}/reject")
    public ApiResponse<?> reject(@PathVariable Long id, @RequestParam(defaultValue = "") String comment) { return ApiResponse.ok(claimService.audit(id, false, comment)); }
}
