package com.obai.juntao.mall.domain;

public enum ProductStatus {
    PUBLIC_COLLECTED,
    INFO_PENDING,
    ENTERPRISE_CLAIMED,
    CANDIDATE_OBSERVING,
    TRUSTED_DISPLAY,
    LONG_TERM_FEEDBACK,
    RECOMMEND_RESTRICTED,
    RISK_FROZEN
}
