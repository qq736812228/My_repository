package com.obai.juntao.mall.service;
import com.obai.juntao.mall.domain.MallEmptySlot;
import com.obai.juntao.mall.dto.CreateSlotRequest;
import com.obai.juntao.mall.repository.MallEmptySlotRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.UUID;
@Service @RequiredArgsConstructor
public class EmptySlotService {
    private final MallEmptySlotRepository repository;
    public List<MallEmptySlot> list() { return repository.findAll(); }
    public MallEmptySlot create(CreateSlotRequest req) {
        MallEmptySlot s = new MallEmptySlot();
        s.setSlotCode("SLOT-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        s.setSlotName(req.slotName()); s.setSlotType(req.slotType()); s.setCategoryCode(req.categoryCode());
        s.setDemandTag(req.demandTag()); s.setReason(req.reason()); s.setDisplayText(req.displayText());
        s.setConversionCondition(req.conversionCondition());
        return repository.save(s);
    }
    public MallEmptySlot convert(Long id) {
        MallEmptySlot s = repository.findById(id).orElseThrow(() -> new IllegalArgumentException("空位不存在"));
        s.setStatus("CONVERTED"); return repository.save(s);
    }
}
