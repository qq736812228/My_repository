package com.obai.juntao.mall.service;
import com.obai.juntao.mall.domain.MallEvidenceFile;
import com.obai.juntao.mall.dto.CreateEvidenceRequest;
import com.obai.juntao.mall.repository.MallEvidenceFileRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
@Service @RequiredArgsConstructor
public class EvidenceService {
    private final MallEvidenceFileRepository repository;
    public MallEvidenceFile create(CreateEvidenceRequest req) {
        MallEvidenceFile e = new MallEvidenceFile();
        e.setProductId(req.productId()); e.setStrainId(req.strainId()); e.setBatchId(req.batchId());
        e.setEvidenceType(req.evidenceType()); e.setFileName(req.fileName()); e.setFileUrl(req.fileUrl());
        e.setIssuer(req.issuer()); e.setAuditComment(req.auditComment());
        return repository.save(e);
    }
    public List<MallEvidenceFile> publicEvidence(Long productId) { return repository.findByProductId(productId); }
}
