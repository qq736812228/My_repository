package com.obai.juntao.mall.dto;
import jakarta.validation.constraints.NotBlank;
public record CreateSlotRequest(
        @NotBlank String slotName,
        @NotBlank String slotType,
        String categoryCode,
        String demandTag,
        @NotBlank String reason,
        String displayText,
        String conversionCondition
) {}
