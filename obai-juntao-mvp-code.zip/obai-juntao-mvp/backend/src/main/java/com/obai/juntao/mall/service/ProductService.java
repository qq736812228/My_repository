package com.obai.juntao.mall.service;

import com.obai.juntao.mall.domain.MallProduct;
import com.obai.juntao.mall.domain.ProductStatus;
import com.obai.juntao.mall.dto.CreateProductRequest;
import com.obai.juntao.mall.repository.MallProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class ProductService {
    private final MallProductRepository productRepository;
    private final ClaimRiskService claimRiskService;
    private final ProductScoreService scoreService;

    public List<MallProduct> list() { return productRepository.findAll(); }
    public MallProduct get(Long id) { return productRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("商品不存在")); }

    public MallProduct create(CreateProductRequest req) {
        MallProduct p = new MallProduct();
        p.setProductCode("PROD-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        p.setProductName(req.productName());
        p.setBrandName(req.brandName());
        p.setManufacturerName(req.manufacturerName());
        p.setEntrustCompanyName(req.entrustCompanyName());
        p.setCategoryCode(req.categoryCode());
        p.setProductType(req.productType());
        p.setSourceType("PUBLIC");
        p.setPublicSourceUrl(req.publicSourceUrl());
        p.setSpecification(req.specification());
        p.setStorageCondition(req.storageCondition());
        p.setSuitablePopulation(req.suitablePopulation());
        p.setUnsuitablePopulation(req.unsuitablePopulation());
        p.setClaimSummary(req.claimSummary());
        MallProduct saved = productRepository.save(p);
        claimRiskService.detect(saved.getId(), saved.getClaimSummary());
        return scoreService.recalculate(saved.getId());
    }

    public MallProduct updateStatus(Long id, ProductStatus status) {
        MallProduct p = get(id);
        p.setStatus(status);
        p.setUpdatedAt(LocalDateTime.now());
        return productRepository.save(p);
    }
}
