package com.obai.juntao.mall.dto;
import jakarta.validation.constraints.NotBlank;
public record StatusUpdateRequest(@NotBlank String status) {}
