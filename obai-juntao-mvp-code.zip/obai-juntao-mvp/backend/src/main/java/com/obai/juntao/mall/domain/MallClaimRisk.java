package com.obai.juntao.mall.domain;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.time.LocalDateTime;

@Getter @Setter
@Entity @Table(name = "mall_claim_risk")
public class MallClaimRisk {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long productId;
    @Column(columnDefinition = "TEXT") private String claimText;
    private String riskType;
    private String riskLevel;
    @Column(columnDefinition = "TEXT") private String matchedKeywords;
    private String reviewStatus = "AUTO_DETECTED";
    private LocalDateTime createdAt = LocalDateTime.now();
}
