package com.obai.juntao.mall.service;

import com.obai.juntao.mall.domain.MallClaimRisk;
import com.obai.juntao.mall.domain.MallClaimRiskRule;
import com.obai.juntao.mall.repository.MallClaimRiskRepository;
import com.obai.juntao.mall.repository.MallClaimRiskRuleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ClaimRiskService {
    private final MallClaimRiskRuleRepository ruleRepository;
    private final MallClaimRiskRepository riskRepository;

    public List<MallClaimRisk> detect(Long productId, String claimText) {
        List<MallClaimRisk> results = new ArrayList<>();
        if (!StringUtils.hasText(claimText)) return results;
        for (MallClaimRiskRule rule : ruleRepository.findByEnabledTrue()) {
            if (claimText.contains(rule.getKeyword())) {
                MallClaimRisk risk = new MallClaimRisk();
                risk.setProductId(productId);
                risk.setClaimText(claimText);
                risk.setRiskType(rule.getRiskType());
                risk.setRiskLevel(rule.getRiskLevel());
                risk.setMatchedKeywords(rule.getKeyword());
                results.add(riskRepository.save(risk));
            }
        }
        return results;
    }
}
