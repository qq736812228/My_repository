package com.obai.juntao.mall.repository;

import com.obai.juntao.mall.domain.*;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface MallProductFeedbackRepository extends JpaRepository<MallProductFeedback, Long> {
    List<MallProductFeedback> findByProductId(Long productId);
    List<MallProductFeedback> findByUserId(Long userId);

}
