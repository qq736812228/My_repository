package com.obai.juntao.mall.dto;

import jakarta.validation.constraints.NotBlank;

public record CreateProductRequest(
        @NotBlank String productName,
        String brandName,
        String manufacturerName,
        String entrustCompanyName,
        @NotBlank String categoryCode,
        @NotBlank String productType,
        String publicSourceUrl,
        String specification,
        String storageCondition,
        String suitablePopulation,
        String unsuitablePopulation,
        String claimSummary
) {}
