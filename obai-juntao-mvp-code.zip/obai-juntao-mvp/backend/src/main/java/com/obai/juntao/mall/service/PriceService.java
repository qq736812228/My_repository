package com.obai.juntao.mall.service;
import com.obai.juntao.mall.domain.MallPriceSnapshot;
import com.obai.juntao.mall.dto.CreatePriceRequest;
import com.obai.juntao.mall.repository.MallPriceSnapshotRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
@Service @RequiredArgsConstructor
public class PriceService {
    private final MallPriceSnapshotRepository repository;
    public MallPriceSnapshot create(CreatePriceRequest req) {
        MallPriceSnapshot p = new MallPriceSnapshot();
        p.setProductId(req.productId()); p.setPlatformName(req.platformName()); p.setShopName(req.shopName());
        p.setPrice(req.price()); p.setUnitPrice(req.unitPrice()); p.setSpecification(req.specification());
        p.setSalesCount(req.salesCount()); p.setCommissionRate(req.commissionRate()); p.setSourceUrl(req.sourceUrl());
        return repository.save(p);
    }
    public List<MallPriceSnapshot> compare(Long productId) { return repository.findByProductIdOrderByCapturedAtDesc(productId); }
}
