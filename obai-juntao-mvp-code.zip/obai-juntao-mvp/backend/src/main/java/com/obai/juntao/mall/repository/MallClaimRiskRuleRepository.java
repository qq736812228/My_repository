package com.obai.juntao.mall.repository;

import com.obai.juntao.mall.domain.*;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface MallClaimRiskRuleRepository extends JpaRepository<MallClaimRiskRule, Long> {
    List<MallClaimRiskRule> findByEnabledTrue();

}
