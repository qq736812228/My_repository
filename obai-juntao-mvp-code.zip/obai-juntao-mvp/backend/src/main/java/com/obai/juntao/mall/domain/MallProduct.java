package com.obai.juntao.mall.domain;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter @Setter
@Entity @Table(name = "mall_product")
public class MallProduct {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String productCode;
    private String productName;
    private String brandName;
    private String manufacturerName;
    private String entrustCompanyName;
    private String categoryCode;
    private String productType;
    @Enumerated(EnumType.STRING)
    private ProductStatus status = ProductStatus.PUBLIC_COLLECTED;
    private String sourceType;
    @Column(columnDefinition = "TEXT") private String publicSourceUrl;
    private String specification;
    @Column(columnDefinition = "TEXT") private String storageCondition;
    @Column(columnDefinition = "TEXT") private String suitablePopulation;
    @Column(columnDefinition = "TEXT") private String unsuitablePopulation;
    @Column(columnDefinition = "TEXT") private String claimSummary;
    private BigDecimal infoIntegrityScore = BigDecimal.ZERO;
    private BigDecimal evidenceScore = BigDecimal.ZERO;
    private BigDecimal riskScore = BigDecimal.ZERO;
    private BigDecimal totalScore = BigDecimal.ZERO;
    @Enumerated(EnumType.STRING)
    private ObaiLevel obaiLevel = ObaiLevel.D;
    private Boolean isRecommendable = false;
    private LocalDateTime createdAt = LocalDateTime.now();
    private LocalDateTime updatedAt = LocalDateTime.now();
}
