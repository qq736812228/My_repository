package com.obai.juntao.mall.domain;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter @Setter
@Entity @Table(name = "mall_evidence_file")
public class MallEvidenceFile {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long productId;
    private Long strainId;
    private Long batchId;
    private String evidenceType;
    private String fileName;
    @Column(columnDefinition = "TEXT") private String fileUrl;
    private String issuer;
    private LocalDate issueDate;
    private LocalDate expireDate;
    private String auditStatus = "PENDING";
    @Column(columnDefinition = "TEXT") private String auditComment;
    private LocalDateTime createdAt = LocalDateTime.now();
}
