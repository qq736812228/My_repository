package com.obai.juntao.mall.service;

import com.obai.juntao.mall.domain.*;
import com.obai.juntao.mall.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import java.math.BigDecimal;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ProductScoreService {
    private final MallProductRepository productRepository;
    private final MallProductStrainRepository productStrainRepository;
    private final MallEvidenceFileRepository evidenceFileRepository;
    private final MallPriceSnapshotRepository priceSnapshotRepository;
    private final MallProductFeedbackRepository feedbackRepository;
    private final MallClaimRiskRepository claimRiskRepository;

    public MallProduct recalculate(Long productId) {
        MallProduct p = productRepository.findById(productId).orElseThrow(() -> new IllegalArgumentException("商品不存在"));
        BigDecimal info = scoreInfo(p);
        BigDecimal strain = scoreStrain(productId);
        BigDecimal batch = scoreEvidence(productId);
        BigDecimal claim = scoreClaim(productId);
        BigDecimal price = scorePrice(productId);
        BigDecimal feedback = scoreFeedback(productId);
        BigDecimal total = info.add(strain).add(batch).add(claim).add(price).add(feedback);
        p.setInfoIntegrityScore(info);
        p.setEvidenceScore(strain.add(batch));
        p.setRiskScore(BigDecimal.TEN.subtract(claim));
        p.setTotalScore(total);
        p.setObaiLevel(level(total));
        p.setIsRecommendable(total.compareTo(BigDecimal.valueOf(85)) >= 0 && claim.compareTo(BigDecimal.valueOf(8)) >= 0);
        return productRepository.save(p);
    }

    private BigDecimal scoreInfo(MallProduct p) {
        int score = 0;
        if (StringUtils.hasText(p.getBrandName())) score += 5;
        if (StringUtils.hasText(p.getManufacturerName())) score += 5;
        if (StringUtils.hasText(p.getEntrustCompanyName())) score += 5;
        if (StringUtils.hasText(p.getSpecification())) score += 5;
        if (StringUtils.hasText(p.getStorageCondition())) score += 5;
        if (StringUtils.hasText(p.getSuitablePopulation()) || StringUtils.hasText(p.getUnsuitablePopulation())) score += 5;
        return BigDecimal.valueOf(score);
    }

    private BigDecimal scoreStrain(Long productId) {
        List<MallProductStrain> list = productStrainRepository.findAll().stream().filter(s -> productId.equals(s.getProductId())).toList();
        if (list.isEmpty()) return BigDecimal.ZERO;
        int score = 0;
        MallProductStrain s = list.get(0);
        if (StringUtils.hasText(s.getDeclaredSpecies())) score += 5;
        if (StringUtils.hasText(s.getDeclaredStrainNo())) score += 8;
        if (StringUtils.hasText(s.getDeclaredCfu())) score += 5;
        if (StringUtils.hasText(s.getCfuAtProduction())) score += 3;
        if (StringUtils.hasText(s.getCfuAtExpiry())) score += 4;
        return BigDecimal.valueOf(score);
    }

    private BigDecimal scoreEvidence(Long productId) {
        List<MallEvidenceFile> files = evidenceFileRepository.findByProductId(productId);
        int score = 0;
        if (!files.isEmpty()) score += 5;
        if (files.stream().anyMatch(f -> "BATCH_TEST".equalsIgnoreCase(f.getEvidenceType()))) score += 5;
        if (files.stream().anyMatch(f -> "SAMPLE_RETENTION".equalsIgnoreCase(f.getEvidenceType()))) score += 3;
        if (files.stream().anyMatch(f -> StringUtils.hasText(f.getIssuer()))) score += 4;
        if (files.stream().anyMatch(f -> "STABILITY".equalsIgnoreCase(f.getEvidenceType()))) score += 3;
        return BigDecimal.valueOf(score);
    }

    private BigDecimal scoreClaim(Long productId) {
        boolean high = claimRiskRepository.findAll().stream()
                .anyMatch(r -> productId.equals(r.getProductId()) && "HIGH".equalsIgnoreCase(r.getRiskLevel()));
        boolean any = claimRiskRepository.findAll().stream().anyMatch(r -> productId.equals(r.getProductId()));
        if (high) return BigDecimal.ZERO;
        if (any) return BigDecimal.valueOf(6);
        return BigDecimal.TEN;
    }

    private BigDecimal scorePrice(Long productId) {
        List<MallPriceSnapshot> prices = priceSnapshotRepository.findByProductIdOrderByCapturedAtDesc(productId);
        return prices.size() >= 2 ? BigDecimal.valueOf(5) : prices.isEmpty() ? BigDecimal.ZERO : BigDecimal.valueOf(2);
    }

    private BigDecimal scoreFeedback(Long productId) {
        int size = feedbackRepository.findByProductId(productId).size();
        if (size >= 50) return BigDecimal.TEN;
        if (size >= 10) return BigDecimal.valueOf(6);
        if (size > 0) return BigDecimal.valueOf(3);
        return BigDecimal.ZERO;
    }

    private ObaiLevel level(BigDecimal total) {
        if (total.compareTo(BigDecimal.valueOf(85)) >= 0) return ObaiLevel.A;
        if (total.compareTo(BigDecimal.valueOf(70)) >= 0) return ObaiLevel.B;
        if (total.compareTo(BigDecimal.valueOf(55)) >= 0) return ObaiLevel.C;
        if (total.compareTo(BigDecimal.valueOf(40)) >= 0) return ObaiLevel.D;
        return ObaiLevel.E;
    }
}
