package com.obai.juntao.mall.domain;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.time.LocalDateTime;

@Getter @Setter
@Entity @Table(name = "mall_claim_risk_rule")
public class MallClaimRiskRule {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String keyword;
    private String riskType;
    private String riskLevel;
    private Boolean enabled = true;
    private LocalDateTime createdAt = LocalDateTime.now();
}
