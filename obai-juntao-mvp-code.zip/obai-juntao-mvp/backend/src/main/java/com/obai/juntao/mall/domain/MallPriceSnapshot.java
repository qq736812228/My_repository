package com.obai.juntao.mall.domain;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter @Setter
@Entity @Table(name = "mall_price_snapshot")
public class MallPriceSnapshot {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long productId;
    private String platformName;
    private String shopName;
    private BigDecimal price;
    private BigDecimal unitPrice;
    private String specification;
    private Integer salesCount;
    private BigDecimal commissionRate;
    @Column(columnDefinition = "TEXT") private String sourceUrl;
    private LocalDateTime capturedAt = LocalDateTime.now();
}
