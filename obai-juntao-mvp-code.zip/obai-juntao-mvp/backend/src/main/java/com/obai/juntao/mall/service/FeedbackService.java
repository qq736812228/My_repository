package com.obai.juntao.mall.service;
import com.obai.juntao.mall.domain.MallProductFeedback;
import com.obai.juntao.mall.dto.CreateFeedbackRequest;
import com.obai.juntao.mall.repository.MallProductFeedbackRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
@Service @RequiredArgsConstructor
public class FeedbackService {
    private final MallProductFeedbackRepository repository;
    public MallProductFeedback create(Long productId, CreateFeedbackRequest req) {
        MallProductFeedback f = new MallProductFeedback();
        f.setProductId(productId); f.setUserId(req.userId() == null ? 0L : req.userId());
        f.setUseStartDate(req.useStartDate()); f.setUseEndDate(req.useEndDate()); f.setDoseDescription(req.doseDescription());
        f.setStoolChangeScore(req.stoolChangeScore()); f.setSleepChangeScore(req.sleepChangeScore());
        f.setEnergyChangeScore(req.energyChangeScore()); f.setDigestionChangeScore(req.digestionChangeScore());
        f.setAdverseFeedback(req.adverseFeedback()); f.setOverallFeedback(req.overallFeedback()); f.setRetestId(req.retestId());
        return repository.save(f);
    }
    public List<MallProductFeedback> byUser(Long userId) { return repository.findByUserId(userId); }
}
