package com.obai.juntao.mall.domain;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.time.LocalDateTime;

@Getter @Setter
@Entity @Table(name = "mall_product_strain")
public class MallProductStrain {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long productId;
    private Long strainId;
    private String declaredSpecies;
    private String declaredStrainNo;
    private String declaredCfu;
    private String cfuAtProduction;
    private String cfuAtExpiry;
    private Boolean isDeclaredClear = false;
    private LocalDateTime createdAt = LocalDateTime.now();
}
