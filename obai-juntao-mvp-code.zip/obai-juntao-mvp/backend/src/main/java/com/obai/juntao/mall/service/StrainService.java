package com.obai.juntao.mall.service;

import com.obai.juntao.mall.domain.MallProductStrain;
import com.obai.juntao.mall.domain.MallStrain;
import com.obai.juntao.mall.dto.BindProductStrainRequest;
import com.obai.juntao.mall.dto.CreateStrainRequest;
import com.obai.juntao.mall.repository.MallProductStrainRepository;
import com.obai.juntao.mall.repository.MallStrainRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class StrainService {
    private final MallStrainRepository strainRepository;
    private final MallProductStrainRepository productStrainRepository;

    public List<MallStrain> list() { return strainRepository.findAll(); }

    public MallStrain create(CreateStrainRequest req) {
        MallStrain s = new MallStrain();
        s.setStrainCode(req.strainCode());
        s.setSpeciesName(req.speciesName());
        s.setGenusName(req.genusName());
        s.setStrainNo(req.strainNo());
        s.setSourceDescription(req.sourceDescription());
        s.setOwnerCompany(req.ownerCompany());
        s.setAuthorizationStatus(req.authorizationStatus());
        s.setFoodUseScope(req.foodUseScope());
        s.setInfantAllowed(Boolean.TRUE.equals(req.infantAllowed()));
        s.setHasHumanEvidence(Boolean.TRUE.equals(req.hasHumanEvidence()));
        s.setHasIndustrialCapacity(Boolean.TRUE.equals(req.hasIndustrialCapacity()));
        s.setHasBatchTest(Boolean.TRUE.equals(req.hasBatchTest()));
        return strainRepository.save(s);
    }

    public MallProductStrain bind(Long productId, BindProductStrainRequest req) {
        MallProductStrain ps = new MallProductStrain();
        ps.setProductId(productId);
        ps.setStrainId(req.strainId());
        ps.setDeclaredSpecies(req.declaredSpecies());
        ps.setDeclaredStrainNo(req.declaredStrainNo());
        ps.setDeclaredCfu(req.declaredCfu());
        ps.setCfuAtProduction(req.cfuAtProduction());
        ps.setCfuAtExpiry(req.cfuAtExpiry());
        ps.setIsDeclaredClear(Boolean.TRUE.equals(req.isDeclaredClear()));
        return productStrainRepository.save(ps);
    }
}
