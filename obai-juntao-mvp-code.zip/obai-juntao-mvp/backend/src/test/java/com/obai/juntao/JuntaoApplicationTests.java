package com.obai.juntao;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
@SpringBootTest
class JuntaoApplicationTests { @Test void contextLoads() {} }
