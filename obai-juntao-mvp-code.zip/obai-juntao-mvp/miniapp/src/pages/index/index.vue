<template>
  <view class="page">
    <view class="hero">
      <text class="title">菌淘</text>
      <text class="sub">菌品可信，价格可比，选择有据，长期可查。</text>
    </view>
    <view class="panel" v-for="p in products" :key="p.id" @click="open(p.id)">
      <view class="row"><text class="name">{{p.productName}}</text><text class="level">{{p.obaiLevel}}</text></view>
      <text class="meta">{{p.brandName || '公开收录'}}｜评分 {{p.totalScore}}</text>
      <text class="tip" v-if="!p.isRecommendable">公开信息不足以支持可信推荐，建议查看证据链。</text>
    </view>
    <button class="slot" @click="goSlots">查看空位以待</button>
  </view>
</template>
<script setup>
import { ref } from 'vue';import { onShow } from '@dcloudio/uni-app';import { listProducts } from '../../api'
const products=ref([]);onShow(async()=>products.value=await listProducts())
function open(id){uni.navigateTo({url:'/pages/product/detail?id='+id})}
function goSlots(){uni.navigateTo({url:'/pages/slot/list'})}
</script>
<style>.page{padding:24rpx;background:#f5fff8;min-height:100vh}.hero{background:#123d2c;color:#fff;border-radius:28rpx;padding:32rpx;margin-bottom:24rpx}.title{display:block;font-size:44rpx;font-weight:700}.sub{display:block;margin-top:12rpx;font-size:26rpx}.panel{background:#fff;border-radius:24rpx;padding:24rpx;margin-bottom:20rpx;box-shadow:0 8rpx 28rpx rgba(0,0,0,.06)}.row{display:flex;justify-content:space-between}.name{font-weight:700;font-size:30rpx}.level{background:#eaf7ed;color:#17613f;border-radius:999rpx;padding:6rpx 16rpx}.meta{display:block;color:#607060;margin-top:12rpx}.tip{display:block;color:#9b4d00;margin-top:12rpx}.slot{background:#df7b26;color:#fff;border-radius:20rpx;margin-top:28rpx}</style>
