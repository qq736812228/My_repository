const BASE = 'http://localhost:8080'
export function request(url, method='GET', data={}) {
  return new Promise((resolve, reject) => {
    uni.request({ url: BASE + url, method, data, success: res => resolve(res.data.data), fail: reject })
  })
}
export const listProducts = () => request('/api/mall/products')
export const listSlots = () => request('/api/mall/empty-slots')
export const getProduct = id => request('/api/mall/products/' + id)
export const submitFeedback = (id, data) => request('/api/mall/products/' + id + '/feedback', 'POST', data)
